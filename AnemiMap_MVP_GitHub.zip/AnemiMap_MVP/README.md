# AnemiMap MVP

Anemiya haqida ma'lumot, simptomlarni dastlabki baholash va tibbiy yordamga yo'naltirish g'oyasini namoyish qiluvchi tanlov prototipi.

> Ushbu MVP tibbiy tashxis qo'ymaydi. Natijalar faqat prototip namoyishi uchun.
